<?php $__env->startSection('pagename'); ?>
    Kendaraan
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('customer.partial.customerNavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="d-flex justify-content-between mb-4">
        <h2>Kendaraan Saya</h2>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addKendaraanModal">
            Tambah Kendaraan
        </button>
    </div>
    <?php if(Session::has('pesan')): ?>
        <div class="alert alert-success"><?php echo e(Session::get('pesan')); ?></div>
        <?php
            Session::forget('pesan');
        ?>
    <?php endif; ?>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>#</th>
                <th>Nama</th>
                <th>Tahun</th>
                <th>Plat Nomor</th>
                <th>Merek</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $kendaraans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $kendaraan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key + 1); ?></td>
                    <td><?php echo e($kendaraan->nama); ?></td>
                    <td><?php echo e($kendaraan->tahun); ?></td>
                    <td><?php echo e($kendaraan->plat_nomor); ?></td>
                    <td><?php echo e($kendaraan->merek); ?></td>
                    <td>
                        <button type="button" class="btn btn-warning btn-sm btn-edit" data-bs-toggle="modal" data-bs-target="#editKendaraanModal"
                                data-id="<?php echo e($kendaraan->id); ?>"
                                data-nama="<?php echo e($kendaraan->nama); ?>"
                                data-tahun="<?php echo e($kendaraan->tahun); ?>"
                                data-plat_nomor="<?php echo e($kendaraan->plat_nomor); ?>"
                                data-merek="<?php echo e($kendaraan->merek); ?>">
                            Edit
                        </button>
                        <button type="button" class="btn btn-danger btn-sm btn-delete" data-bs-toggle="modal" data-bs-target="#deleteKendaraanModal"
                                data-id="<?php echo e($kendaraan->id); ?>">
                            Hapus
                        </button>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<!-- Modal to Add New Kendaraan -->
<div class="modal fade" id="addKendaraanModal" tabindex="-1" aria-labelledby="addKendaraanModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form id="formTambahKendaraan" method="POST" action="<?php echo e(route('tambah_kendaraan')); ?>">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title" id="addKendaraanModalLabel">Tambah Kendaraan</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="nama" class="form-label">Nama</label>
                        <input type="text" class="form-control" id="nama" name="nama" required>
                    </div>
                    <div class="mb-3">
                        <label for="tahun" class="form-label">Tahun</label>
                        <input type="text" class="form-control" id="tahun" name="tahun" required>
                    </div>
                    <div class="mb-3">
                        <label for="plat_nomor" class="form-label">Plat Nomor</label>
                        <input type="text" class="form-control" id="plat_nomor" name="plat_nomor" required>
                    </div>
                    <div class="mb-3">
                        <label for="merek" class="form-label">Merek</label>
                        <input type="text" class="form-control" id="merek" name="merek" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                    <button type="submit" class="btn btn-primary">Tambah Kendaraan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal to Edit Kendaraan -->
<div class="modal fade" id="editKendaraanModal" tabindex="-1" aria-labelledby="editKendaraanModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form id="formEditKendaraan" method="POST" action="<?php echo e(route('edit_kendaraan')); ?>">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title" id="editKendaraanModalLabel">Edit Kendaraan</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="edit_id" name="id">
                    <div class="mb-3">
                        <label for="edit_nama" class="form-label">Nama</label>
                        <input type="text" class="form-control" id="edit_nama" name="nama" required>
                    </div>
                    <div class="mb-3">
                        <label for="edit_tahun" class="form-label">Tahun</label>
                        <input type="text" class="form-control" id="edit_tahun" name="tahun" required>
                    </div>
                    <div class="mb-3">
                        <label for="edit_plat_nomor" class="form-label">Plat Nomor</label>
                        <input type="text" class="form-control" id="edit_plat_nomor" name="plat_nomor" required>
                    </div>
                    <div class="mb-3">
                        <label for="edit_merek" class="form-label">Merek</label>
                        <input type="text" class="form-control" id="edit_merek" name="merek" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                    <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal to Confirm Delete Kendaraan -->
<div class="modal fade" id="deleteKendaraanModal" tabindex="-1" aria-labelledby="deleteKendaraanModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form id="formDeleteKendaraan" method="POST" action="<?php echo e(route('delete_kendaraan')); ?>">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteKendaraanModalLabel">Hapus Kendaraan</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="delete_id" name="id">
                    <p>Apakah Anda yakin ingin menghapus kendaraan ini?</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                    <button type="submit" class="btn btn-danger">Hapus</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_script'); ?>
<script>
    $(document).ready(function() {
        // Edit button click handler
        $('.btn-edit').on('click', function() {
            var id = $(this).data('id');
            var nama = $(this).data('nama');
            var tahun = $(this).data('tahun');
            var plat_nomor = $(this).data('plat_nomor');
            var merek = $(this).data('merek');

            $('#edit_id').val(id);
            $('#edit_nama').val(nama);
            $('#edit_tahun').val(tahun);
            $('#edit_plat_nomor').val(plat_nomor);
            $('#edit_merek').val(merek);
        });

        // Delete button click handler
        $('.btn-delete').on('click', function() {
            var id = $(this).data('id');
            $('#delete_id').val(id);
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\Documents\kerjaan\LBLaravel\resources\views/customer/kendaraan.blade.php ENDPATH**/ ?>