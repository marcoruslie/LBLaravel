<footer class="bg-body text-center align-center w-100">
    Copyright UD. ASIA MOTOR
</footer>
<?php /**PATH C:\Users\ASUS\Documents\kerjaan\LBLaravel\resources\views/admin/partial/adminFooter.blade.php ENDPATH**/ ?>