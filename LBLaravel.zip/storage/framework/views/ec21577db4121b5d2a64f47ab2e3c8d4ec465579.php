<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
</head>
<style>
    * {
        margin: 0;
        padding: 0;
    }

    html body {
        width: 100vw;
        height: 100vh;
    }
</style>

<body>

    <div class="row align-items-center m-0 bg-secondary" style="height: 100vh; width: 100vw">
        <div class="col"></div>
        <div class="col bg-dark rounded-4 py-4 px-4 align-items-center">
            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pesanError): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert alert-danger"><?php echo e($pesanError); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <form action="" method="post">
                <?php echo csrf_field(); ?>
                <div class="row-4 mb-3 text-white text-center fs-1 fw-bold">REGISTER FORM</div>
                
                <div class="form-floating mb-2">
                    <input name="namaLengkap" type="text" class="form-control" id="floatingPassword"
                        placeholder="Password">
                    <label for="floatingPassword">Nama Lengkap</label>
                </div>
                <div class="form-floating mb-2">
                    <input name="username" type="text" class="form-control" id="floatingInput"
                        placeholder="name@example.com">
                    <label for="floatingInput">Username</label>
                </div>

                <div class="form-floating mb-2">
                    <input name="alamat" type="text" class="form-control" id="floatingInput"
                        placeholder="name@example.com">
                    <label for="floatingInput">Alamat</label>
                </div>
                <div class="form-floating mb-2">
                    <input name="notelp" type="number" class="form-control" id="floatingInput"
                        placeholder="name@example.com">
                    <label for="floatingInput">Nomor Telepon</label>
                </div>
                <div class="form-floating mb-2">
                    <input name="password" type="password" class="form-control" id="floatingPassword"
                        placeholder="Password">
                    <label for="floatingPassword">Password</label>
                </div>
                <div class="form-floating mb-2">
                    <input name="password_confirmation" type="password" class="form-control" id="floatingPassword"
                        placeholder="Password">
                    <label for="floatingPassword">Confirm Password</label>
                </div>

                <div class="text-white">
                    Gender :
                    <input type="radio" name="gender" id="" value="2">Perempuan
                    <input type="radio" name="gender" id="" value="1">Laki - Laki
                </div>
                <div class="row">
                    <div class="col"></div>
                    <div class="col d-flex justify-content-center">
                        <input type="submit" class="btn btn-outline-light mt-2" value="REGISTER">
                    </div>
                    <div class="col"></div>
                </div>
                <div class="text-white text-center">
                    Already have an account? <a href="/">sign in</a>
                </div>
            </form>
        </div>
        <div class="col"></div>
</body>

</html>
<?php /**PATH C:\Users\ASUS\Documents\kerjaan\LBLaravel\resources\views/customer/register.blade.php ENDPATH**/ ?>