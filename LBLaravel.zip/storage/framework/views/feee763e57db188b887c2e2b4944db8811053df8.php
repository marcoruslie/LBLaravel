<?php $__env->startSection('pagename'); ?>
    Login
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php
        // $userData = DB::table('users')->get();
        // $tokoData = DB::table('toko')->get();
        // dd($data);
    ?>
    <div class="row align-items-center m-0 bg-secondary" style="height: 100vh; width: 100vw">
        <div class="col"></div>
        <div class="col bg-dark rounded-2 py-4 px-4 align-items-center">

            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pesanError): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert alert-danger"><?php echo e($pesanError); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php if(Session::has('pesan')): ?>
                <div class="alert alert-success"><?php echo e(Session::get('pesan')); ?></div>
                <?php
                    Session::forget('pesan');
                ?>
            <?php elseif(Session::has('pesanError')): ?>
                <div class="alert alert-danger"><?php echo e(Session::get('pesanError')); ?></div>
                <?php
                    Session::forget('pesanError');
                ?>
            <?php endif; ?>
            <div class="row-4 mb-3 text-white text-center fs-1 fw-bold">UD. ASIA MOTOR</div>
            <form action="<?php echo e(route('customer_login')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-floating mb-3">
                    
                    <input name="username" type="text" class="form-control" id="floatingInput">
                    <label for="floatingInput">Username</label>
                </div>
                <div class="form-floating">
                    
                    <input name="password" type="password" class="form-control" id="floatingPassword">
                    <label for="floatingPassword">Password</label>
                </div>
                <div class="d-flex justify-content-center">
                    <input type="submit" class="btn btn-outline-light mt-2" value="Log in">
                </div>
            </form>
            <div class="d-flex justify-content-center">
                <div class="text-white">
                    still dont have an account?
                    <a href="<?php echo e(url('/register')); ?>">sign up</a>
                </div>
            </div>
        </div>
        <div class="col"></div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <div class="text-black text-center">© 2024 Asia Motor</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layoutIndex', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\Documents\kerjaan\LBLaravel\resources\views/login.blade.php ENDPATH**/ ?>